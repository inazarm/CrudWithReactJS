import Configuration from './../Configuration/Configuration';

const  Config=new Configuration();
export default class CrudServices {
    
    CreateRecord(data){
        console.log("Data : ",data, " URL : ",Config.CreateRecord)
    }
}
